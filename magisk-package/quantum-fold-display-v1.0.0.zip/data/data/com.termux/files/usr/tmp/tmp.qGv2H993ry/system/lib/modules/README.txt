# NOTE: In production, these would be pre-compiled .ko files
